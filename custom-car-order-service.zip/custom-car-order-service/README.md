# Custom Car Order Service

## Overview
The Custom Car Order Service is a Spring Boot application that allows customers to customize and order vehicles. It provides a RESTful API for registering car orders with various customizable options such as engine type, color, wheels, sound system, interior, roof, and GPS navigation.

## Features
- **Customizable Vehicles**: Users can specify various configurations for their vehicles.
- **Builder Pattern**: Utilizes the Builder pattern for creating complex `Automobile` objects, enhancing code readability and maintainability.
- **JWT Authentication**: Implements JWT for secure authentication and authorization.
- **PostgreSQL Database**: Stores order information in a PostgreSQL database.

## Project Structure
```
custom-car-order-service
├── src
│   ├── main
│   │   ├── java
│   │   │   └── com
│   │   │       └── company
│   │   │           └── customcar
│   │   │               ├── CustomCarOrderServiceApplication.java
│   │   │               ├── domain
│   │   │               │   ├── model
│   │   │               │   │   └── Automobile.java
│   │   │               │   ├── builder
│   │   │               │   │   └── AutomobileBuilder.java
│   │   │               │   └── repository
│   │   │               │       └── OrderRepository.java
│   │   │               ├── application
│   │   │               │   ├── service
│   │   │               │   │   └── RegisterOrderService.java
│   │   │               │   └── dto
│   │   │               │       └── RegisterOrderRequest.java
│   │   │               └── infrastructure
│   │   │                   ├── config
│   │   │                   │   └── SecurityConfig.java
│   │   │                   ├── controller
│   │   │                   │   └── RegisterOrderController.java
│   │   │                   ├── persistence
│   │   │                   │   ├── entity
│   │   │                   │   │   └── OrderEntity.java
│   │   │                   │   └── JpaOrderRepository.java
│   │   │                   └── security
│   │   │                       └── JwtProvider.java
│   │   └── resources
│   │       ├── application.properties
│   │       └── db
│   │           └── migration
│   │               └── V1__init.sql
│   └── test
│       └── java
│           └── com
│               └── company
│                   └── customcar
│                       ├── application
│                       │   └── service
│                       │       └── RegisterOrderServiceTest.java
│                       └── infrastructure
│                           └── controller
│                               └── RegisterOrderControllerTest.java
├── .gitignore
├── build.gradle
└── README.md
```

## Setup Instructions
1. **Clone the Repository**: 
   ```
   git clone <repository-url>
   cd custom-car-order-service
   ```

2. **Configure Database**: Update the `src/main/resources/application.properties` file with your PostgreSQL database credentials.

3. **Build the Project**: Use Gradle to build the project.
   ```
   ./gradlew build
   ```

4. **Run the Application**: Start the Spring Boot application.
   ```
   ./gradlew bootRun
   ```

5. **Access the API**: The application will be available at `http://localhost:8080`. You can register a new car order by sending a POST request to `/register`.

## Usage
To register a new car order, send a POST request to the `/register` endpoint with a JSON body containing the vehicle configuration. Example:
```json
{
  "engineType": "V8",
  "color": "Red",
  "wheels": "Alloy",
  "soundSystem": "Premium",
  "interior": "Leather",
  "roof": "Sunroof",
  "gps": true
}
```

## License
This project is licensed under the MIT License. See the LICENSE file for more details.