package com.company.customcar.infrastructure.persistence.entity;

import com.company.customcar.domain.model.Automobile;
import jakarta.persistence.*;
import lombok.Getter;

import java.time.LocalDateTime;

@Getter
@Entity
@Table(name = "orders")
public class OrderEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String customerName;

    @Column(nullable = false)
    private String automobileDetails;

    @Column(nullable = false)
    private LocalDateTime orderDate;

    // Constructors, getters, and setters

    public OrderEntity() {
    }

    public OrderEntity(String customerName, String automobileDetails, LocalDateTime orderDate) {
        this.customerName = customerName;
        this.automobileDetails = automobileDetails;
        this.orderDate = orderDate;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setAutomobileDetails(String automobileDetails) {
        this.automobileDetails = automobileDetails;
    }

    public void setOrderDate(LocalDateTime orderDate) {
        this.orderDate = orderDate;
    }


    public void setAutomobile(Automobile automobile) {
        if (automobile == null) {
            throw new IllegalArgumentException("El objeto Automobile no puede ser nulo.");
        }
        this.automobileDetails = String.format(
                "Engine: %s, Color: %s, Wheels: %s, SoundSystem: %s, Interior: %s, Roof: %s, GPS: %b",
                automobile.getEngineType(),
                automobile.getColor(),
                automobile.getWheels(),
                automobile.getSoundSystem(),
                automobile.getInterior(),
                automobile.getRoof(),
                automobile.isGpsNavigation()
        );
    }

}