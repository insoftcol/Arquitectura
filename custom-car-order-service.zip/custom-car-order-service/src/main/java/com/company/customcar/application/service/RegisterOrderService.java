package com.company.customcar.application.service;

import com.company.customcar.domain.builder.AutomobileBuilder;
import com.company.customcar.domain.model.Automobile;
import com.company.customcar.domain.repository.OrderRepository;
import com.company.customcar.application.dto.RegisterOrderRequest;
import com.company.customcar.infrastructure.persistence.entity.OrderEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RegisterOrderService {

    private final OrderRepository orderRepository;

    @Autowired
    public RegisterOrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    @Transactional
    public OrderEntity registerOrder(RegisterOrderRequest request) {
        Automobile automobile = new AutomobileBuilder()
                .setEngineType(request.getEngineType())
                .setColor(request.getColor())
                .setWheels(request.getWheels())
                .setSoundSystem(request.getSoundSystem())
                .setInterior(request.getInterior())
                .setRoof(request.getRoof())
                .setGpsNavigation(request.isGpsNavigation())
                .build();
// Validación para asegurar que el objeto Automobile no sea nulo
        if (automobile == null) {
            throw new IllegalArgumentException("El objeto Automobile no puede ser nulo.");
        }
        OrderEntity orderEntity = new OrderEntity();
        orderEntity.setAutomobile(automobile);
        orderEntity.setCustomerName(request.getCustomerName());
        orderEntity.setOrderDate(request.getOrderDate());

        return orderRepository.save(orderEntity);
    }
}