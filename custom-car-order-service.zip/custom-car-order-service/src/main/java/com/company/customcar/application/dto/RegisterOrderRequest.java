package com.company.customcar.application.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class RegisterOrderRequest {
    private String engineType;
    private String color;
    private String wheels;
    private String soundSystem;
    private String interior;
    private String roof;
    private boolean gpsNavigation;

    public RegisterOrderRequest(String engineType, String color, String wheels, String soundSystem, String interior, String roof, boolean gpsNavigation) {
        // Inicialización de campos
        this.engineType = engineType;
        this.color = color;
        this.wheels = wheels;
        this.soundSystem = soundSystem;
        this.interior = interior;
        this.roof = roof;
        this.gpsNavigation = gpsNavigation;

    }
    public String getCustomerName() {
        // Assuming customerName is a field in this class

        return "John Doe"; // Placeholder for actual customer name
    }

    public LocalDateTime getOrderDate() {
        // Assuming orderDate is a field in this class

        return LocalDateTime.now(); // Placeholder for actual order date
    }

    public Object isGps() {
        // Assuming isGps is a field in this class

        return true; // Placeholder for actual GPS value
    }

    // Additional fields can be added as needed
}