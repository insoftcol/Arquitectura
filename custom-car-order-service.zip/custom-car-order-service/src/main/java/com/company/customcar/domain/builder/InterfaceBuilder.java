package com.company.customcar.domain.builder;

public interface InterfaceBuilder <T>{
    // Marker interface for builder pattern
    // This can be used to enforce a common contract for all builders
    // or to provide additional utility methods if needed in the future

    T build();
}
