package com.company.customcar.domain.builder;

import com.company.customcar.domain.model.Automobile;

public class AutomobileBuilder implements InterfaceBuilder<Automobile>{
    private String engineType;
    private String color;
    private String wheels;
    private String soundSystem;
    private String interior;
    private String roof;
    private boolean gpsNavigation;

    public AutomobileBuilder setEngineType(String engineType) {
        this.engineType = engineType;
        return this;
    }

    public AutomobileBuilder setColor(String color) {
        this.color = color;
        return this;
    }

    public AutomobileBuilder setWheels(String wheels) {
        this.wheels = wheels;
        return this;
    }

    public AutomobileBuilder setSoundSystem(String soundSystem) {
        this.soundSystem = soundSystem;
        return this;
    }

    public AutomobileBuilder setInterior(String interior) {
        this.interior = interior;
        return this;
    }

    public AutomobileBuilder setRoof(String roof) {
        this.roof = roof;
        return this;
    }

    public AutomobileBuilder setGpsNavigation(boolean gpsNavigation) {
        this.gpsNavigation = gpsNavigation;
        return this;
    }
@Override
    public Automobile build() {

            return Automobile.builder()
                    .engineType(engineType)
                    .color(color)
                    .wheels(wheels)
                    .soundSystem(soundSystem)
                    .interior(interior)
                    .roof(roof)
                    .gpsNavigation(gpsNavigation)
                    .build();

    }

    public AutomobileBuilder setGps(Object gps) {

        return this;
    }
}