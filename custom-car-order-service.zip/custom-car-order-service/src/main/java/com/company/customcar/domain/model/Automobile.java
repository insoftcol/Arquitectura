package com.company.customcar.domain.model;

import lombok.Getter;

import java.util.Objects;

@Getter
public class Automobile {
    private final String engineType;
    private final String color;
    private final String wheels;
    private final String soundSystem;
    private final String interior;
    private final String roof;
    private final boolean gpsNavigation;

    private Automobile(AutomobileBuilder builder) {
        this.engineType = builder.engineType;
        this.color = builder.color;
        this.wheels = builder.wheels;
        this.soundSystem = builder.soundSystem;
        this.interior = builder.interior;
        this.roof = builder.roof;
        this.gpsNavigation = builder.gpsNavigation;
    }

    public static AutomobileBuilder builder() {
        return new AutomobileBuilder();
    }

    public static class AutomobileBuilder {
        private String engineType;
        private String color;
        private String wheels;
        private String soundSystem;
        private String interior;
        private String roof;
        private boolean gpsNavigation;

        public AutomobileBuilder engineType(String engineType) {
            this.engineType = engineType;
            return this;
        }

        public AutomobileBuilder color(String color) {
            this.color = color;
            return this;
        }

        public AutomobileBuilder wheels(String wheels) {
            this.wheels = wheels;
            return this;
        }

        public AutomobileBuilder soundSystem(String soundSystem) {
            this.soundSystem = soundSystem;
            return this;
        }

        public AutomobileBuilder interior(String interior) {
            this.interior = interior;
            return this;
        }

        public AutomobileBuilder roof(String roof) {
            this.roof = roof;
            return this;
        }

        public AutomobileBuilder gpsNavigation(boolean gpsNavigation) {
            this.gpsNavigation = gpsNavigation;
            return this;
        }

        public Automobile build() {
            return new Automobile(this);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Automobile)) return false;
        Automobile that = (Automobile) o;
        return gpsNavigation == that.gpsNavigation &&
                Objects.equals(engineType, that.engineType) &&
                Objects.equals(color, that.color) &&
                Objects.equals(wheels, that.wheels) &&
                Objects.equals(soundSystem, that.soundSystem) &&
                Objects.equals(interior, that.interior) &&
                Objects.equals(roof, that.roof);
    }

    @Override
    public int hashCode() {
        return Objects.hash(engineType, color, wheels, soundSystem, interior, roof, gpsNavigation);
    }
}