package com.company.customcar.infrastructure.controller;

import com.company.customcar.application.dto.RegisterOrderRequest;
import com.company.customcar.application.service.RegisterOrderService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class RegisterOrderController {

    private final RegisterOrderService registerOrderService;

    public RegisterOrderController(RegisterOrderService registerOrderService) {
        this.registerOrderService = registerOrderService;
    }

    @PostMapping("/register")
    public ResponseEntity<String> registerOrder(@RequestBody RegisterOrderRequest request) {
        try {
            registerOrderService.registerOrder(request);
            return ResponseEntity.status(HttpStatus.CREATED).body("Order registered successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error registering order: " + e.getMessage());
        }
    }
}