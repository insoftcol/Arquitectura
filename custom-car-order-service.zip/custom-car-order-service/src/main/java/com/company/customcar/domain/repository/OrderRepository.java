package com.company.customcar.domain.repository;

import com.company.customcar.infrastructure.persistence.entity.OrderEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.lang.System;

@Repository
public interface OrderRepository extends JpaRepository<OrderEntity, Long> {
    // Custom query methods can be defined here if needed

    OrderEntity save(OrderEntity orderEntity);

}