package com.company.customcar.infrastructure.persistence;

import com.company.customcar.domain.repository.OrderRepository;
import com.company.customcar.infrastructure.persistence.entity.OrderEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JpaOrderRepository extends OrderRepository, JpaRepository<OrderEntity, Long> {
}