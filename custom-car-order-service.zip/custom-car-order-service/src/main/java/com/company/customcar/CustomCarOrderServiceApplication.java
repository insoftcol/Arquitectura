package com.company.customcar;

        import com.company.customcar.application.dto.RegisterOrderRequest;
        import com.company.customcar.application.service.RegisterOrderService;
        import org.springframework.boot.CommandLineRunner;
        import org.springframework.boot.SpringApplication;
        import org.springframework.boot.autoconfigure.SpringBootApplication;
        import org.springframework.context.annotation.Bean;

        @SpringBootApplication
        public class CustomCarOrderServiceApplication {

            public static void main(String[] args) {
                SpringApplication.run(CustomCarOrderServiceApplication.class, args);
                System.out.println("Iniciando Orden de servicio para construccion de automovil personalizado ...");
            }

            @Bean
            public CommandLineRunner run(RegisterOrderService registerOrderService) {
                return args -> {
                    /*RegisterOrderRequest sportsCarRequest = new RegisterOrderRequest(
                            "V12", "Yellow", "Alloy", "Premium", "Leather", "Convertible", true
                    );*/
                    // Construcción de un automóvil con parámetros opcionales usando el patrón Builder
                    RegisterOrderRequest sportsCarRequest = RegisterOrderRequest.builder()
                            .engineType("V12")
                            .color("Red")
                            .wheels("Alloy")
                            .soundSystem("Standard")
                            .interior("Leather PVC")
                            .gpsNavigation(true)
                            .build();

                    registerOrderService.registerOrder(sportsCarRequest);
                    System.out.println("Solicitud de vehículo deportivo creada: " + sportsCarRequest);
                };
            }
        }