CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    engine_type VARCHAR(50) NOT NULL,
    color VARCHAR(30) NOT NULL,
    wheels VARCHAR(30) NOT NULL,
    sound_system VARCHAR(50),
    interior VARCHAR(50),
    roof VARCHAR(30),
    gps_navigation BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);