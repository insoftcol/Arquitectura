package com.company.customcar.infrastructure.controller;

import com.company.customcar.application.dto.RegisterOrderRequest;
import com.company.customcar.infrastructure.persistence.entity.OrderEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import java.time.LocalDateTime;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import com.company.customcar.application.service.RegisterOrderService;

class RegisterOrderControllerTest {

    @InjectMocks
    private RegisterOrderController registerOrderController;

    @Mock
    private RegisterOrderService registerOrderService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterOrder() {
        //RegisterOrderRequest request = new RegisterOrderRequest();
        RegisterOrderRequest request = new RegisterOrderRequest(
                "V8", "Red", "Alloy", "Premium", "Leather", "Sunroof", true
        );
        // Set properties of request as needed for the test
        OrderEntity mockOrderEntity = new OrderEntity();
        mockOrderEntity.setId(1L);
        mockOrderEntity.setCustomerName("Test Customer");
        mockOrderEntity.setAutomobileDetails("Test Details");
        mockOrderEntity.setOrderDate(java.time.LocalDateTime.now());
        when(registerOrderService.registerOrder(any(RegisterOrderRequest.class))).thenReturn(mockOrderEntity);

        ResponseEntity<String> response = registerOrderController.registerOrder(request);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Order registered successfully.", response.getBody());

        ArgumentCaptor<RegisterOrderRequest> captor = ArgumentCaptor.forClass(RegisterOrderRequest.class);
        verify(registerOrderService).registerOrder(captor.capture());
        assertEquals(request, captor.getValue());
    }

    @Test
    void testRegisterOrderFailure() {

        RegisterOrderRequest request = new RegisterOrderRequest(
                "V8", "Red", "Alloy", "Premium", "Leather", "Sunroof", true
        );
        // Set properties of request to simulate failure

        when(registerOrderService.registerOrder(any(RegisterOrderRequest.class))).thenThrow(new RuntimeException("Order registration failed"));

        ResponseEntity<String> response = registerOrderController.registerOrder(request);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Error registering order: Order registration failed", response.getBody());
    }
}