package com.company.customcar.application.service;

import com.company.customcar.domain.builder.AutomobileBuilder;
import com.company.customcar.domain.model.Automobile;
import com.company.customcar.domain.repository.OrderRepository;
import com.company.customcar.application.dto.RegisterOrderRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class RegisterOrderServiceTest {

    @InjectMocks
    private RegisterOrderService registerOrderService;

    @Mock
    private OrderRepository orderRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterOrder_Success() {
//        /*RegisterOrderRequest request = new RegisterOrderRequest();
//        request.setEngineType("V8");
//        request.setColor("Red");
//        request.setWheels("Alloy");
//        request.setSoundSystem("Premium");
//        request.setInterior("Leather");
//        request.setRoof("Sunroof");
//        request.setGps(true);*/

        RegisterOrderRequest request = new RegisterOrderRequest(
                "V8", "Red", "Alloy", "Premium", "Leather", "Sunroof", true
        );

        Automobile automobile = new AutomobileBuilder()
                .setEngineType(request.getEngineType())
                .setColor(request.getColor())
                .setWheels(request.getWheels())
                .setSoundSystem(request.getSoundSystem())
                .setInterior(request.getInterior())
                .setRoof(request.getRoof())
                .setGps(request.isGps())
                .build();

        when(orderRepository.save(any())).thenReturn(null); // Mocking save method

        registerOrderService.registerOrder(request);

        verify(orderRepository, times(1)).save(any());
    }

    @Test
    void testRegisterOrder_Failure() {
        //RegisterOrderRequest request = new RegisterOrderRequest();
        RegisterOrderRequest request = new RegisterOrderRequest(
                "V8", "Red", "Alloy", "Premium", "Leather", "Sunroof", true
        );
        // Set invalid data to trigger failure scenario

        // Assuming the service throws an exception for invalid data
        // when(orderRepository.save(any())).thenThrow(new RuntimeException("Invalid order"));

        // Uncomment the following line when the exception handling is implemented
        // assertThrows(RuntimeException.class, () -> registerOrderService.registerOrder(request));
    }
}